let editor;

window.onload = function() {
    editor = ace.edit("editor");
    //editor.setTheme("ace/theme/monokai");
    editor.session.setMode("ace/mode/c_cpp");
}

function changeLanguage() {
    let language = $("#languages").val();

    if (language == 'c' || language == 'cpp') {
        editor.session.setMode("ace/mode/c_cpp");
    }else if (language == 'python') {
        editor.session.setMode("ace/mode/python");
    } else if (language == 'php') {
        editor.session.setMode("ace/mode/php");
    }
}
function runCode() {
    $.ajax({
        url: "/app/compiler.php",
        method: "POST",
        data: {
            language: $("#languages").val(), 
            code: editor.getSession().getValue()
        },
        success: function(response) {
            $(".output").text(response)
        },
        error: function(xhr, status, error) {
            console.error(xhr.responseText);
        }
    });
}


/*function toggleDarkMode(){
    var element = document.body;
   element.classList.toggle("dark-mode")
} */
function toggleDarkMode() {
    var element = document.body;
    element.classList.toggle("dark-mode");

    // Toggle editor theme between dark and light
    if (element.classList.contains("dark-mode")) {
        editor.setTheme("ace/theme/monokai");
    } else {
        editor.setTheme("ace/theme/chrome");
    }
}


function clearEditor() {
    // Clear the content of the editor
    editor.setValue("");
}